# Todo

Make the hierarchy view as a treeview so that the user can fold elements.
Rename `message` to `email`
