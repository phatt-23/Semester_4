from comps.component import Component


class CalendarView(Component):

    pass
